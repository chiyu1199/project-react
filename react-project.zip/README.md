# react综合实战项目
## E宠商城
## 项目简介
  本项目是模仿线上的电商项目E宠商城进行开发的。所有的比例均是按照其官网的比例设置的
## 项目主要涉及技术
  1. react
  2. react-router-dom
  3. axios
  4. redux
  5. react-redux
  6. swiper
  7. better-scroll
  ......
## 在word中写了一点项目流程和需要注意的地方，可参考