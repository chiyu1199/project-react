// 头部处理显示想隐藏广告
export const HANDLE_SHOW = 'HANDLESHOW';


// 动态切换nav底部样式
export const NAV_INDEX = 'NAVINDEX';

// 更新navList数据的
export const CHANGE_NAV = 'CHANGE_NAV';

// 获取header头部的高度
export const GET_HEIGHT = 'GET_HEIGHT';


export const GET_FOOTER_HEIGHT = 'GET_FOOTER_HEIGHT';

export const GET_COLUMN_DATA = 'GET_COLUMN_DATA';


export const GET_CAROUSEL_DATA = 'GET_CAROUSEL_DATA';


export const GET_MORELIST_DATA = 'GET_MORELIST_DATA';

// 分类页classify数据
export const GET_CLASSIFY_DATA = 'GET_CLASSIFY_DATA';

export const GET_BRAND_DATA = 'GET_BRAND_DATA';

export const GET_MENU_DATA = 'GET_MENU_DATA';

